License
=======

.. include:: ../LICENSE.md
